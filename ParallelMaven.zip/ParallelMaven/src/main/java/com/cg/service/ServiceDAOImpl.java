package com.cg.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.EnableTransactionManagement;
import org.springframework.transaction.annotation.Transactional;

import com.cg.dao.JPAWalletDAO;
import com.cg.dao.WalletDAO;
import com.cg.dto.Customer;
import com.cg.dto.History;
import com.cg.exceptions.InputException;
@Service
@EnableTransactionManagement
public class ServiceDAOImpl implements ServiceDAO {
	@Autowired
	private WalletDAO dao;
	
	public ServiceDAOImpl(){
		dao=new JPAWalletDAO();
	}
	
	@Override
	public List<Customer> findAll() {
		System.out.println("Service Layer working");
		return dao.findAll();
	}

	@Override
	public Customer findById(int id) {
		return dao.findById(id);
	}

	@Override
	@Transactional
	public void create(Customer customer) {
		dao.create(customer);
	}

	@Override
	@Transactional
	public void update(Customer customer) {
		dao.update(customer);
	}

	@Override
	@Transactional
	public void delete(String[] ids) {
		dao.delete(ids);
	}

	@Override
	@Transactional
	public void deposit(float amount, int id) {
		dao.deposit(amount, id);
	}

	@Override
	@Transactional
	public void withdraw(float amount, int id) {
		dao.withdraw(amount, id);
	}

	@Override
	@Transactional
	public void transfer(float amount, int idfrom, String mobNo) {
		dao.transfer(amount, idfrom, mobNo);
	}

	@Override
	public Customer findByMob(String mobileNo) {
		return dao.findByMob(mobileNo);
	}

	@Override
	@Transactional
	public void addToHist(History history) {
		dao.addToHist(history);
	}

	@Override
	public List<History> showHist(String mobNo) {
		return dao.showHist(mobNo);
		
	}

	@Override
	public boolean validateWithdraw(String mobileNo, float amount) throws InputException {
		if(!mobileNo.matches("[0-9]{10}"))
			throw new InputException("Please enter a valid 10 digit mobile number!");
		if(amount<0)
			throw new InputException("Please enter a positive amount");
		if(amount>(dao.findByMob(mobileNo).getBalance()))
			throw new InputException("Insufficient Funds");
		return true;
	}

	@Override
	public boolean validateDeposit(String mobileNo, float amount) throws InputException {
		if(!mobileNo.matches("[0-9]{10}"))
			throw new InputException("Please enter a valid 10 digit mobile number!");
		if(amount<0)
			throw new InputException("Please enter a positive amount");
		return true;
	}

	@Override
	public boolean validateTransfer(String mobileNoFrom, String mobileNoTo, float amount) throws InputException{
		if(!mobileNoFrom.matches("[0-9]{10}"))
			throw new InputException("Please enter a valid 10 digit mobile number to transfer from!");
		if(!mobileNoTo.matches("[0-9]{10}"))
			throw new InputException("Please enter a valid 10 digit mobile number to transfer to!");
		if(amount>(dao.findByMob(mobileNoFrom).getBalance()))
			throw new InputException("Insufficient Funds");
		if(amount<0)
			throw new InputException("Please enter a positive amount");
		if(mobileNoFrom.compareTo(mobileNoTo) == 0)
			throw new InputException("Accounts cannot be the same!");
		return true;
	}

	@Override
	public boolean validateNumber(String mobileNo) throws InputException {
		if(!mobileNo.matches("[0-9]{10}"))
			throw new InputException("Please enter a valid 10 digit mobile number!");
		return true;
	}

}
