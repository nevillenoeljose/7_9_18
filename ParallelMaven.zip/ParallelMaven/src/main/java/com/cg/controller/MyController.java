package com.cg.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.cg.dto.Customer;
import com.cg.dto.History;
import com.cg.service.ServiceDAO;

@Controller
@RequestMapping("/controller")
public class MyController {
	private static final String ACTION_KEY = "action";
	private static final String VIEW_LIST_ACTION = "viewCustList";
	private static final String ADD_CUST_ACTION = "addCust";
	private static final String SAVE_CUST_ACTION = "saveCust";
	private static final String EDIT_CUST_ACTION = "editCust";
	private static final String DELETE_CUST_ACTION = "deleteCust";
	private static final String DEPOSIT_CUST_ACTION = "depositCust";
	private static final String WITHDRAW_CUST_ACTION = "withdrawCust";
	private static final String TRANSFER_CUST_ACTION = "transferCust";
	private static final String MANUAL_ACTION = "manualEntry";
	private static final String MOVE = "moveForward";
	private static final String HISTORY = "showHistory";
	private static final String HISTORY_INPUT = "inputHistory";
	private static final String ERROR_KEY = "errorMessage";
	
	@Autowired
	private ServiceDAO wser;

	{
		System.out.println("In controller");
	}
	
	// All options working
	@RequestMapping(method = RequestMethod.GET)
	protected String processViewAddRequest(ModelMap map, @RequestParam(ACTION_KEY) String actionName) {
		if (VIEW_LIST_ACTION.equals(actionName)) {
			List<Customer> customers = wser.findAll();
			map.addAttribute("custList", customers);
			return "custList";
		} else if(ADD_CUST_ACTION.equals(actionName)) {
			return "custForm";
		} else if(MANUAL_ACTION.equals(actionName)) {
			return "manualEntry";
		} else if(HISTORY_INPUT.equals(actionName)) {
			return "histInput";
		} else {
			String errorMessage = "[" + actionName + "] is not a valid action.";
			map.addAttribute(ERROR_KEY, errorMessage);
			return null;
		}
	}
	
	// All options working
	@RequestMapping(method = RequestMethod.GET, params = "id")
	protected String processSearchRequest(ModelMap map, @RequestParam(ACTION_KEY) String actionName,
			@RequestParam(value = "id", required = false) int id) {
		if (EDIT_CUST_ACTION.equals(actionName)) {
			Customer customer = wser.findById(id);
			map.addAttribute("customer", customer);
			return "custForm";
		} else if (DEPOSIT_CUST_ACTION.equals(actionName)) {
			Customer customer = wser.findById(id);
			map.addAttribute("customer", customer);
			return "deposit";
		} else if(WITHDRAW_CUST_ACTION.equals(actionName)){
			Customer customer = wser.findById(id);
			map.addAttribute("customer", customer);
			return "withdraw";
		} else if(TRANSFER_CUST_ACTION.equals(actionName)) {
			Customer customer = wser.findById(id);
			map.addAttribute("customer", customer);
			return "transfer";
		} else if(MANUAL_ACTION.equals(actionName)) {
			return "manualEntry";
		} else {
			String errorMessage = "[" + actionName + "] is not a valid action.";
			map.addAttribute(ERROR_KEY, errorMessage);
			return null;
		}
	}
	
	// Working
	@RequestMapping(method = RequestMethod.GET, params = "mobileNo")
	protected String processHistoryRequest(ModelMap map,
			@RequestParam(ACTION_KEY) String actionName,
			@RequestParam(value = "mobileNo", required = true) String mobileNo) {
			try{
				if(wser.validateNumber(mobileNo)){
					if (HISTORY.equals(actionName)) {
						List<History> history = wser.showHist(mobileNo);
						map.addAttribute("histList", history);
						return "histList";
					} else {
						String errorMessage = "[" + actionName + "] is not a valid action.";
						map.addAttribute(ERROR_KEY, errorMessage);
						return null;
					}
				}
			} catch (Exception e){
				System.err.println(e.getMessage());
				System.out.println("Please try again!");
				map.addAttribute("error", e.getMessage());
				return "errorPage";
			}
			return null; 
	}
	
	// Working
	@RequestMapping(method = RequestMethod.POST, params = { "id" })
	protected String processDeleteRequest(ModelMap map, 
			@RequestParam(ACTION_KEY) String actionName,
			@RequestParam(value = "id", required = false) String[] ids, 
			@Valid @ModelAttribute("customer") Customer customer,
			BindingResult result) {
			if(result.hasErrors()){
				return "custForm";
			}
			else if (SAVE_CUST_ACTION.equals(actionName)) {

				if (customer.getId() == -1) {
					customer.setId(0);
					wser.create(customer);
				}
				else{
					wser.update(customer);
				}
					List<Customer> customers = wser.findAll();
					map.addAttribute("custList", customers);
					return "custList";

		} else if (DELETE_CUST_ACTION.equals(actionName)) {
			wser.delete(ids);
			List<Customer> customers = wser.findAll();
			map.addAttribute("custList", customers);
			return "custList";

		} else {
			String errorMessage = "[" + actionName + "] is not a valid action.";
			map.addAttribute(ERROR_KEY, errorMessage);
			return null;
		}

	}
	
	// Working
	@RequestMapping(method = RequestMethod.POST, params = { "id", "amount" })
	protected String processOpRequest(ModelMap map, 
			@RequestParam(ACTION_KEY) String actionName,
			@RequestParam(value = "id", required = false) String[] ids,
			@RequestParam(value = "amount") float amount,
			@RequestParam(value = "trans", required = false) String transNo,
			@ModelAttribute("customer") Customer customer) {
		  if (DEPOSIT_CUST_ACTION.equals(actionName)) {
			wser.deposit(amount, Integer.parseInt(ids[0]));
			List<Customer> customers = wser.findAll();
			map.addAttribute("custList", customers);
			return "custList";
		} else if (DELETE_CUST_ACTION.equals(actionName)) {
			wser.delete(ids);
			List<Customer> customers = wser.findAll();
			map.addAttribute("custList", customers);
			return "custList";
		} else if (WITHDRAW_CUST_ACTION.equals(actionName)) {
			wser.withdraw(amount, Integer.parseInt(ids[0]));
			List<Customer> customers = wser.findAll();
			map.addAttribute("custList", customers);
			return "custList";
		} else if (TRANSFER_CUST_ACTION.equals(actionName)) {
			wser.transfer(amount, Integer.parseInt(ids[0]), transNo);
			List<Customer> customers = wser.findAll();
			map.addAttribute("custList", customers);
			return "custList";
		} else {
			String errorMessage = "[" + actionName + "] is not a valid action.";
			map.addAttribute(ERROR_KEY, errorMessage);
			return null;
		}

	}
	
	// Working	
	@RequestMapping(method = RequestMethod.POST, params = { "mobileNo", "operation", "trans", "amount" })
	protected String processManualRequest(ModelMap map, 
			@RequestParam(ACTION_KEY) String actionName,
			@RequestParam("mobileNo") String mobileNo,
			@RequestParam("amount") float amount,
			@RequestParam("operation") int op,
			@RequestParam(value = "trans", required = false) String transNo)
		{
		if (MOVE.equals(actionName) && op == 1) {
			wser.deposit(amount, wser.findByMob(mobileNo).getId());
			List<Customer> customers = wser.findAll();
			map.addAttribute("custList", customers);
			return "custList";
		} else if (MOVE.equals(actionName) && op == 2) {
			wser.withdraw(amount, wser.findByMob(mobileNo).getId());
			List<Customer> customers = wser.findAll();
			map.addAttribute("custList", customers);
			return "custList";
		} else if (MOVE.equals(actionName) && op == 3) {
			wser.transfer(amount, wser.findByMob(mobileNo).getId(), transNo);
			List<Customer> customers = wser.findAll();
			map.addAttribute("custList", customers);
			return "custList";
		} else {
			String errorMessage = "[" + actionName + "] is not a valid action.";
			map.addAttribute(ERROR_KEY, errorMessage);
			return null;
		}

	}	
		
	@ModelAttribute("customer")
	protected Customer makeCust() {
		Customer customer = new Customer();
		return customer;

	}

}