package com.cg.dao;

import java.time.LocalDateTime;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.cg.dao.WalletDAO;
import com.cg.dto.Customer;
import com.cg.dto.History;
@Repository

public class JPAWalletDAO implements WalletDAO {
	
	@PersistenceContext
	private EntityManager entityManager;

	@SuppressWarnings("unchecked")
	@Override
	public List<Customer> findAll() {
		try {
			Query query = entityManager.createQuery("select customer from Customer customer");
			return query.getResultList();
		} finally {
			entityManager.close();
		}
	}
	
	@Override
	public Customer findById(int id) {
		try {
			Query query = 
				entityManager.createQuery("select customer from Customer customer where ID = ?");
			query.setParameter(1, id);
			return (Customer) query.getSingleResult();
		} finally {
			entityManager.close();
		}
	}
	
	@Override
	public Customer findByMob(String mobileNo) {
		try {
			Query query = 
				entityManager.createQuery("select customer from Customer customer where mobileNo = ?");
			query.setParameter(1, mobileNo);
			return (Customer) query.getSingleResult();
		} finally {
			entityManager.close();
		}
	}
	
	@Override
	public void create(Customer customer) {
		try {
			entityManager.persist(customer);
	      	System.out.println("Customer added succesfully!");
			return;
		} finally {
			entityManager.close();
		}
	}
	
	@Override
	public void update(Customer customer) {
		try {
			entityManager.merge(customer);
	      	System.out.println("Customer updated succesfully!");
			return;
		} finally {
			entityManager.close();
		}
	}

	@Override
	public void delete(String[] ids) {
		for(String id:ids) {
			Query query = 
					entityManager.createQuery("select customer from Customer customer where ID = ?");
			query.setParameter(1, id);
			Customer delCust = (Customer) query.getSingleResult();
			entityManager.remove(delCust);	
		}

	}

	@Override
	public void deposit(float amount, int id) {
		try {
			System.out.println("inside deposit jpa");
			Query query = 
				entityManager.createQuery("select customer from Customer customer where ID = ?");
			query.setParameter(1, id);
			Customer depCust = (Customer) query.getSingleResult();
			float oldBal = depCust.getBalance();
			float newBal = oldBal + amount;
			depCust.setBalance(newBal);
			LocalDateTime timeRaw =  LocalDateTime.now();
			String time = timeRaw.toString();
			History hist1 = new History(depCust.getMobileNo(), "Deposit", amount, time);
			addToHist(hist1);			
			entityManager.merge(depCust);
			System.out.println("Deposit Successful!");
		} finally {
			entityManager.close();
		}		
	}

	@Override
	public void withdraw(float amount, int id) {
		try {
			Query query = 
				entityManager.createQuery("select customer from Customer customer where ID = ?");
			query.setParameter(1, id);
			Customer withCust = (Customer) query.getSingleResult();
			float oldBal = withCust.getBalance();
			float newBal = oldBal - amount;
			withCust.setBalance(newBal);
			LocalDateTime timeRaw =  LocalDateTime.now();
			String time = timeRaw.toString();
			History hist2 = new History(withCust.getMobileNo(), "Withdraw", amount, time);
			addToHist(hist2);		
			entityManager.merge(withCust);
			System.out.println("Withdrawal Successful!");
		} finally {
			entityManager.close();
		}			
	}

	@Override
	public void transfer(float amount, int idfrom, String mobNo) {
		try{
			Query query = 
				entityManager.createQuery("select customer from Customer customer where ID = ?");
			query.setParameter(1, idfrom);
			Customer fromCust = (Customer) query.getSingleResult();
			float oldBalFrom = fromCust.getBalance();
			float newBalFrom = oldBalFrom - amount;
			fromCust.setBalance(newBalFrom);
			Customer toCust = findByMob(mobNo);
			float oldBalTo = toCust.getBalance();
			float newBalTo = oldBalTo + amount;
			toCust.setBalance(newBalTo);
			LocalDateTime timeRaw =  LocalDateTime.now();
			String timeFrom = timeRaw.toString().concat("From");
			History histFrom = new History(fromCust.getMobileNo(), "Transfer (From)", amount, timeFrom);
			String timeTo = timeRaw.toString().concat("To");
			History histTo = new History(toCust.getMobileNo(), "Transfer (To)", amount, timeTo);
			addToHist(histFrom);
			addToHist(histTo);
			entityManager.merge(fromCust);
			entityManager.merge(toCust);
		} finally {
			entityManager.close();
		}
	}

	@Override
	public void addToHist(History history) {
		try{
			entityManager.persist(history);
		} finally {
			entityManager.close();
		}		
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<History> showHist(String mobNo) {
			Query query = 
					entityManager.createQuery("select history from History history where histMobileNo = ?");
			query.setParameter(1, mobNo);
			List<History> result = query.getResultList();
			System.out.println(result);
			return result;		
	}

}
